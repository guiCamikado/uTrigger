// Classe responsavel pelas apis
#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <WiFi.h>

#include <HTTPSServer.hpp>
#include <SSLCert.hpp>

#include "keys/cert.h"        // const server_cert[], server_cert_len
#include "keys/private_key.h" // const private_key[], private_key_len

#include "ServoMotor.h"

using namespace httpsserver;

class ApiController {
private:
  // Certificado e servidor — ponteiros para evitar inicialização prematura
  SSLCert *_cert;
  HTTPSServer *_secureServer;

  // Instância estática para acesso nos callbacks
  static ApiController *_instance;

  // Handlers estáticos (exigidos pela API da biblioteca HTTPSServer)
  static void handleRootStatic(HTTPRequest *req, HTTPResponse *res) { _instance->handleRoot(req, res); }
  static void handleAssetsStatic(HTTPRequest *req, HTTPResponse *res) { _instance->handleAssets(req, res); }
  static void handleControlStatic(HTTPRequest *req, HTTPResponse *res) { _instance->handleControl(req, res); }
  static void handle404Static(HTTPRequest *req, HTTPResponse *res) { _instance->handle404(req, res); }

  // Handlers de instância (têm acesso a membros da classe)
  void handleRoot(HTTPRequest *req, HTTPResponse *res) {
    File file = LittleFS.open("/index.html", "r");
    if (!file) {
      res->setStatusCode(404);
      res->setHeader("Content-Type", "text/plain");
      res->println("index.html nao encontrado");
      return;
    }
    res->setHeader("Content-Type", "text/html");
    uint8_t buffer[512];
    while (file.available()) {
      size_t len = file.read(buffer, sizeof(buffer));
      res->write(buffer, len);
    }
    file.close();
  }

  // Serve arquivos estáticos (.js, .css, imagens, etc.)
  void handleAssets(HTTPRequest *req, HTTPResponse *res) {
    String path = String(req->getRequestString().c_str());

    File file = LittleFS.open(path, "r");
    if (!file) {
      res->setStatusCode(404);
      res->setHeader("Content-Type", "text/plain");
      res->println("Arquivo nao encontrado");
      return;
    }

    if (path.endsWith(".js")) {
      res->setHeader("Content-Type", "application/javascript");
    } else if (path.endsWith(".css")) {
      res->setHeader("Content-Type", "text/css");
    } else if (path.endsWith(".png")) {
      res->setHeader("Content-Type", "image/png");
    } else if (path.endsWith(".html")) {
      res->setHeader("Content-Type", "text/html");
    } else {
      res->setHeader("Content-Type", "application/octet-stream");
    }

    uint8_t buffer[512];
    while (file.available()) {
      size_t len = file.read(buffer, sizeof(buffer));
      res->write(buffer, len);
    }
    file.close();
  }

  // Fallback: tenta servir o arquivo solicitado; caso não exista, retorna 404
  void handle404(HTTPRequest *req, HTTPResponse *res) {
    // getRequestString() já retorna apenas o path (sem método nem versão HTTP)
    String path = String(req->getRequestString().c_str());
    Serial.println("404 handler — path: " + path);

    File file = LittleFS.open(path, "r");
    if (!file) {
      res->setStatusCode(404);
      res->setHeader("Content-Type", "text/plain");
      res->println("404 Not Found");
      return;
    }

    if (path.endsWith(".html")) {
      res->setHeader("Content-Type", "text/html");
    } else if (path.endsWith(".js")) {
      res->setHeader("Content-Type", "application/javascript");
    } else if (path.endsWith(".css")) {
      res->setHeader("Content-Type", "text/css");
    } else if (path.endsWith(".png")) {
      res->setHeader("Content-Type", "image/png");
    } else {
      res->setHeader("Content-Type", "application/octet-stream");
    }

    uint8_t buffer[512];
    while (file.available()) {
      size_t len = file.read(buffer, sizeof(buffer));
      res->write(buffer, len);
    }
    file.close();
  }

  void handleControl(HTTPRequest *req, HTTPResponse *res) {
    // CORS
    res->setHeader("Access-Control-Allow-Origin", "*");
    res->setHeader("Access-Control-Allow-Headers", "*");
    res->setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");

    // Preflight OPTIONS
    if (req->getMethod() == "OPTIONS") {
      res->setStatusCode(200);
      return;
    }

    // Leitura do body
    std::string body = "";
    char buffer[512];
    size_t len;
    do {
      len = req->readChars(buffer, sizeof(buffer));
      body.append(buffer, len);
    } while (len > 0);

    Serial.println(body.c_str());

    // Parse JSON
    DynamicJsonDocument doc(512);
    DeserializationError error = deserializeJson(doc, body);

    if (error) {
      res->setStatusCode(400);
      res->setHeader("Content-Type", "application/json");
      res->println("{\"success\":false,\"error\":\"JSON invalido\"}");
      return;
    }

    // Extração dos dados
    unsigned long _hitscore = doc["hitscore"].as<unsigned long>();
    unsigned long _pictureTime = doc["pictureTime"].as<unsigned long>();
    unsigned long _sentTime = doc["sendTime"].as<unsigned long>();
    unsigned long _pictureTimeFrame = doc["pictureTimeFrame"].as<unsigned long>();
    unsigned long _timeScored = doc["timeScored"].as<unsigned long>();
    String _measurementUnit = doc["measurementUnity"].as<String>();

    servo.cheatLogic(_hitscore, _pictureTime, _sentTime, _pictureTimeFrame, _timeScored);

    res->setStatusCode(200);
    res->setHeader("Content-Type", "application/json");
    res->println("{\"success\":true}");
  }

public:
  ServoMotor servo;

  ApiController() : _cert(nullptr), _secureServer(nullptr) { _instance = this; }

  void begin() {
    if (!LittleFS.begin(true)) {
      Serial.println("Erro ao montar LittleFS!");
      return;
    }
    Serial.println("LittleFS OK");

    // Usa os tamanhos corretos (binários — não usar strlen em dados DER)
    SSLCert cert = SSLCert((unsigned char *)server_cert, strlen(server_cert) + 1, (unsigned char *)private_key,
                           strlen(private_key) + 1);
                           
    HTTPSServer secureServer(&cert);

    // Registro das rotas
    ResourceNode *nodeRoot = new ResourceNode("/", "GET", handleRootStatic);
    ResourceNode *nodeAssets = new ResourceNode("/assets/*", "GET", handleAssetsStatic);
    ResourceNode *nodeControl = new ResourceNode("/control", "POST", handleControlStatic);
    ResourceNode *nodeOptions = new ResourceNode("/control", "OPTIONS", handleControlStatic);
    ResourceNode *node404 = new ResourceNode("", "GET", handle404Static);

    _secureServer->registerNode(nodeRoot);
    _secureServer->registerNode(nodeAssets);
    _secureServer->registerNode(nodeControl);
    _secureServer->registerNode(nodeOptions);
    _secureServer->setDefaultNode(node404); // fallback correto para 404

    _secureServer->start();
    Serial.println("HTTPS Server iniciado");
  }

  // Deve ser chamado no loop() principal
  void handle() {
    if (_secureServer) { _secureServer->loop(); }
    servo.update();
  }
};

// Definição do ponteiro estático (necessária em um .cpp; aqui fica no .h por simplicidade)
ApiController *ApiController::_instance = nullptr;